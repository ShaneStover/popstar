# Popstar-External
**Fortnite External with no spread, no recoil, ray casting, perfect bullet tracers, e.g.. Double buffered caching runs 1k on the lowest end PCs with Pickups, Containers, Supplydrops, and Buildings enabled. Interface includes a fully interactive leaderboard system, quick bar, and menu.** <br /> <br />
Fortnite External that was sold for a month or two in my discord, ragebaited into a virus total scam and numerous P2Cs started reselling, for the safety of the community dropping the source to the big GH.

<img width="1919" height="1079" alt="image (1)" src="https://github.com/user-attachments/assets/eaf86032-dd22-4a51-9689-4d815d004ba0" />

https://github.com/user-attachments/assets/a0068bee-4d0a-4fc7-b979-d87628830eb6

