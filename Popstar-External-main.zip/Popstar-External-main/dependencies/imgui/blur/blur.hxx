#pragma once
ID3D11PixelShader* pshader = nullptr;
ID3D11ShaderResourceView* tex = nullptr;

struct ImGui_ImplDX11_Data {
    ID3D11Device* pd3dDevice;
    ID3D11DeviceContext* pd3dDeviceContext;
    IDXGIFactory* pFactory;
    ID3D11Buffer* pVB;
    ID3D11Buffer* pIB;
    ID3D11VertexShader* pVertexShader;
    ID3D11InputLayout* pInputLayout;
    ID3D11Buffer* pVertexConstantBuffer;
    ID3D11PixelShader* pPixelShader;
    ID3D11SamplerState* pFontSampler;
    ID3D11ShaderResourceView* pFontTextureView;
    ID3D11RasterizerState* pRasterizerState;
    ID3D11BlendState* pBlendState;
    ID3D11DepthStencilState* pDepthStencilState;
    int                         VertexBufferSize;
    int                         IndexBufferSize;

    ImGui_ImplDX11_Data( ) { memset( ( void* )this, 0, sizeof( *this ) ); VertexBufferSize = 1; IndexBufferSize = 1; }
};

void safe_release( IUnknown*& resource ) {
    if ( resource != nullptr ) {
        resource->Release( );
        resource = nullptr;
    }
}

void get_back_buffer( IDXGISwapChain* swap_chain ) {
    ID3D11Texture2D* back_buffer = nullptr;
    swap_chain->GetBuffer( 0, IID_PPV_ARGS( &back_buffer ) );

    D3D11_TEXTURE2D_DESC desc;
    back_buffer->GetDesc( &desc );
    desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;

    ID3D11Texture2D* back_buffer_tex = NULL;
    g_overlay->m_d3d_device->CreateTexture2D( &desc, nullptr, &back_buffer_tex );
    g_overlay->m_device_context->CopyResource( back_buffer_tex, back_buffer );

    D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc = {};
    srvDesc.Format = desc.Format;
    srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
    srvDesc.Texture2D.MipLevels = desc.MipLevels;
    srvDesc.Texture2D.MostDetailedMip = 0;

    safe_release( reinterpret_cast< IUnknown*& >( tex ) );
    g_overlay->m_d3d_device->CreateShaderResourceView( back_buffer_tex, &srvDesc, &tex );

    safe_release( reinterpret_cast< IUnknown*& >( back_buffer ) );
    safe_release( reinterpret_cast< IUnknown*& >( back_buffer_tex ) );
}

void begin( const ImDrawList* d, const ImDrawCmd* cmd ) {
    const auto swap_chain = reinterpret_cast< IDXGISwapChain* >( cmd->UserCallbackData );
    auto bd = ( ImGui_ImplDX11_Data* )ImGui::GetIO( ).BackendRendererUserData;

    if ( !tex )
        get_back_buffer( swap_chain );

    if ( !pshader ) {
        g_overlay->m_d3d_device->CreatePixelShader( pshaderd, sizeof( pshaderd ), NULL, &pshader );
    }

    g_overlay->m_device_context->PSSetShader( pshader, nullptr, 0 );
    g_overlay->m_device_context->PSSetSamplers( 0, 1, &bd->pFontSampler );
}

void release( const ImDrawList* d, const ImDrawCmd* cmd ) {
    safe_release( reinterpret_cast< IUnknown*& >( tex ) );
}

void draw_background_blur( ImDrawList* draw_list, ImVec2 start, ImVec2 end, ImColor blur_color, int rounding = 0 ) {
    draw_list->AddCallback( begin, g_overlay->m_swap_chain );
    draw_list->AddImageRounded( tex, start, end, start / ImGui::GetIO( ).DisplaySize, end / ImGui::GetIO( ).DisplaySize, blur_color, rounding );
    draw_list->AddCallback( ImDrawCallback_ResetRenderState, 0 );
}